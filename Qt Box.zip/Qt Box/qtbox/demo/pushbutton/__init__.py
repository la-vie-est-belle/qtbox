from .func import demo1, demo2, demo3
from .style import demo1, demo2, demo3, demo4, demo5, demo6, demo7, demo8, demo9, demo10, demo11, demo12
