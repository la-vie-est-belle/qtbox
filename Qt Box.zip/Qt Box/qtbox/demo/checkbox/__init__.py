from .func import demo1, demo2
from .style import demo1, demo2, demo3, demo4