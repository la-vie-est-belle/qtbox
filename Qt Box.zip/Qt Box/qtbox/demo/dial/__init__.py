from .func import demo1
from .style import demo1, demo2